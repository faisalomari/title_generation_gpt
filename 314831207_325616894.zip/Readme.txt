In the main folder, there is one file for the report which is 325616894_ 314831207_report.pdf, and a folder called src, in the src:
1)The main is the code file, which has the training code and the testing code to generate the titles and use the model, simply run the notebook, to only test it, you have to run the initialisations of the model, and then to run the last code snippet with a given skills.
2) logs folder for the logs of the model saved while training.
3) help_files folder that has python scripts to visualize the graphs in addition to the graphs pngs.
4) The data we used for training in the csv file. 

For additional information you can browse our GitHub repository: https://github.com/faisalomari/title_generation_gpt

Submitters:
Faisal Omari - 325616894
Saji Assi - 314831207